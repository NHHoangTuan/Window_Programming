﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBindingOneObject
{
    class MobilePhone
    {
        public string Name { get; set; }
        public string ImagePath { get; set; }
        public string Manufacturer { get; set; }
        public int Price { get; set; }

    }
}
